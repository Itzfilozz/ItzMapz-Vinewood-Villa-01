fx_version 'cerulean'
game 'gta5'

author 'itz.fil0zz'
description 'A new FiveM MLO situated in Vinewood!'
version '1.0.0'


this_is_a_map 'yes'



data_file('DLC_ITYP_REQUEST')('stream/itzmapz-winewoodvilla-01.ytyp')